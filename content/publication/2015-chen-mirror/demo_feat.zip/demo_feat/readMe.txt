features (ELF18) used in chen2015CVDCA and chen2015mirror.

run main.m for details.

If you use our features, please kindly cite our papers.

@inproceedings{chen2015CVDCA,
  title={An Asymmetric Distance Model for Cross-view Feature Mapping in Person Re-identification},
  author={Chen, Ying-Cong and Zheng, Wei-Shi and Yuen, Pong C. and Lai, Jianhuang},
  booktitle={IEEE Transactions on Circuits and Systems for Video Technology},
  year={2015}
}

@inproceedings{chen2015mirror,
  title={Mirror representation for modeling view-specific transform in person re-identification},
  author={Chen, Ying-Cong and Zheng, Wei-Shi and Lai, Jianhuang},
  booktitle={IJCAI},
  year={2015}
}
