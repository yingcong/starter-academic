addpath feat
clear,clc,close all
I = imread('example.jpg');
feat = ELF18Feat(I);