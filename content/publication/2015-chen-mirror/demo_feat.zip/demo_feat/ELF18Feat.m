% ELF-18 feature extraction
% Chen, Ying-Cong, Wei-Shi Zheng, and Jianhuang Lai. 
% "Mirror representation for modeling view-specific transform in person re-identification." 
% Proc. IJCAI. 2015.
function feat = ELF18Feat(I)
part=partition(I);
feat = [];
featureType={'rgb','HS','Lab','ycbcr','NTSC','gabor'};
for i = 1 : numel(part)
    for j = 1 : numel(featureType)
        feat = [feat;feval([featureType{j} 'Extract'],part{i})];
    end
end

end