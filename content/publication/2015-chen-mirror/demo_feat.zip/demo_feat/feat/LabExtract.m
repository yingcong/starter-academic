function hist_=LabExtract(I,dim)
if nargin==1
    dim=16;
end
colorTransform = makecform('srgb2lab');
I = applycform(I, colorTransform);
hist_=rgbExtract(I,dim);
hist_(1:16)=[];
end