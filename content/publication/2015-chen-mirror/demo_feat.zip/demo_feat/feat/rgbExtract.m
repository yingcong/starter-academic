function hist_=rgbExtract(I,dim)
if nargin==1
    dim=16;
end
R=I(:,:,1);G=I(:,:,2);B=I(:,:,3);
histR=imhist(R,dim);histG=imhist(G,dim);histB=imhist(B,dim);
histR=histR/(sum(histR)+eps);histG=histG/(sum(histG)+eps);histB=histB/(sum(histB)+eps);
hist_=[histR;histG;histB];
end