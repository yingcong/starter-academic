function hist_=HSExtract(I,dim)
if nargin==1
    dim=16;
elseif nargin == 2
    [row,col,~] = size(I);
    mask = ones(row,col);
end
I=rgb2hsv(I);
hist_=rgbExtract(I,dim);
hist_(33:end)=[];
end