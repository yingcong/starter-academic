function [Yhist CBhist CRhist] = ComputeYCbCrHistogram(I,nYCbCrbins)
%COMPUTEYCBCRHISTOGRAM computes YCbCr histogram of the image patch
%   input:
%       I           -   the image patch
%       nYCbCrbins  -   number of bins of each histogram
%       mask        -   the mask (optional)
%   output:
%       Yhist CBhist and CRhist are YCbCr histograms respectively
% 
%   by Shizhe Chen
% 


if(isscalar(nYCbCrbins))
    nYCbCrbins = [1 1 1]*nYCbCrbins;
end

YCBCR = rgb2ycbcr(I);

Y = YCBCR(:,:,1);
CB = YCBCR(:,:,2);
CR = YCBCR(:,:,3);


Y = Y(:);
CB = CB(:);
CR = CR(:);


Yhist = histogram(Y,[16 235],nYCbCrbins(1));
CBhist = histogram(CB,[16 240],nYCbCrbins(2));
CRhist = histogram(CR,[16 240],nYCbCrbins(3));

Yhist = Yhist(:);
CBhist = CBhist(:);
CRhist = CRhist(:);

if sum(Yhist)>0
    Yhist = Yhist/sum(Yhist);
end
if sum(CBhist)>0
    CBhist = CBhist/sum(CBhist);
end
if sum(CRhist)>0
    CRhist = CRhist/sum(CRhist);
end
