function hist_=ycbcrExtract(I,dim)
% I=rgb2ycbcr(I);
% hist_=rgbExtract(I);
if nargin==1
    dim=16;
end
 [Yhist CBhist CRhist] = ComputeYCbCrHistogram(I,dim);
 hist_=[Yhist;CBhist;CRhist];
end