function hist_=NTSCExtract(I,dim)
if nargin==1
    dim=16;
end
I=rgb2ntsc(I);
% hist_=rgbExtract(I);
% hist_(1:16)=[];
I_=I(:,:,2);
Q_=I(:,:,3);
I_=I_(:);Q_=Q_(:);
[hist_I,bin] = histogram(I_,[-0.6 0.6],dim);
[hist_Q,bin] = histogram(Q_,[-0.52 0.52],dim);
hist_I=hist_I/(sum(hist_I)+eps);
hist_Q=hist_Q/(sum(hist_Q)+eps);

hist_=[hist_I;hist_Q];

end