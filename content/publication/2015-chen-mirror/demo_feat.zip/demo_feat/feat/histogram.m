function [n,bin] = histogram(data,range,nbins)
%HISTOGRAM computes the 1-D histogram
%   input:
%       data    -   input data
%       range   -   the range of the bins [min,max]
%       nbins   -   the number of the bins
%   output:
%       n   -   the number of values in data that fall in each bin
%       bin -   the index matrix
% 
%   by Shizhe Chen
%
edges = linspace(range(1),range(2),nbins+1);
[n bin] = histc(data,edges);
if(n(end)~=0)
    n(end-1) = n(end-1) + n(end);
    bin(bin==nbins+1) = nbins;   
end
n = n(1:end-1);
n=n(:);