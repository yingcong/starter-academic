function part=partition(I,varargin)
for i=1:2:numel(varargin)
    paraName=varargin{i};
    eval([paraName,'=',num2str(varargin{i+1}),';']);
end
if ~exist('partNum')
    partNum=18;
end
if ~exist('movStepRatio')
    movStepRatio=1;
end

%     [row,~,~]=size(I);
%     len=floor(row/partNum);
%     start=1;
%     for i=1:partNum
%         part{i}=I(start:start+len-1,:,:);
%         start=start+len;
%     end
[row,col,~]=size(I);
partSize=ceil(row/partNum);
I=imresize(I,[partSize*partNum,col]);
[row,col,~]=size(I);
movStep=floor(partSize*movStepRatio);
start=1;
i=1;
while start+partSize-1<=row
    part{i}=I(start:start+partSize-1,:,:);
    start=start+movStep;
    i=i+1;
end

end