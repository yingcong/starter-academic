function hist_=gaborExtract(I,dim)
if nargin==1
    dim=16;
end
if  (size(I,3)==3)
	I=rgb2gray(I);
end
% imshow(I);
I=double(I);
phi=0;bandwidth=0;
gf=makeGaborFilter(0.3,0,4,2,  phi,  bandwidth);
Y{1}=imfilter(I,gf);
gf=makeGaborFilter(0.3,0,8,2,  phi,  bandwidth);
Y{2}=imfilter(I,gf);
gf=makeGaborFilter(0.4,0,4,1,phi,  bandwidth);
Y{3}=imfilter(I,gf);
gf=makeGaborFilter(0.4,0,8,1,  phi,  bandwidth);
Y{4}=imfilter(I,gf);
gf=makeGaborFilter(0.3,90,4,2,  phi,  bandwidth);
Y{5}=imfilter(I,gf);
gf=makeGaborFilter(0.3,90,8,2,  phi,  bandwidth);
Y{6}=imfilter(I,gf);
gf=makeGaborFilter(0.4,90,4,1,  phi,  bandwidth);
Y{7}=imfilter(I,gf);
gf=makeGaborFilter(0.4,90,8,1,  phi,  bandwidth);
Y{8}=imfilter(I,gf);

gf=makeGaborFilter(0.3,45,4,2,  phi,  bandwidth);
Y{9}=imfilter(I,gf);
gf=makeGaborFilter(0.3,45,8,2,  phi,  bandwidth);
Y{10}=imfilter(I,gf);
gf=makeGaborFilter(0.4,45,4,1,phi,  bandwidth);
Y{11}=imfilter(I,gf);
gf=makeGaborFilter(0.4,45,8,1,  phi,  bandwidth);
Y{12}=imfilter(I,gf);
gf=makeGaborFilter(0.3,135,4,2,  phi,  bandwidth);
Y{13}=imfilter(I,gf);
gf=makeGaborFilter(0.3,135,8,2,  phi,  bandwidth);
Y{14}=imfilter(I,gf);
gf=makeGaborFilter(0.4,135,4,1,  phi,  bandwidth);
Y{15}=imfilter(I,gf);
gf=makeGaborFilter(0.4,135,8,1,  phi,  bandwidth);
Y{16}=imfilter(I,gf);



% gf=makeGaborFilter(0.5,0,8,1,  phi,  bandwidth);
% Y{17}=imfilter(I,gf);
% gf=makeGaborFilter(0.5,45,8,1,  phi,  bandwidth);
% Y{18}=imfilter(I,gf);
% gf=makeGaborFilter(0.5,90,8,1,  phi,  bandwidth);
% Y{19}=imfilter(I,gf);
% gf=makeGaborFilter(0.5,135,8,1,  phi,  bandwidth);
% Y{20}=imfilter(I,gf);
% gf=makeGaborFilter(0.6,0,8,1,  phi,  bandwidth);
% Y{21}=imfilter(I,gf);
% gf=makeGaborFilter(0.6,45,8,1,  phi,  bandwidth);
% Y{22}=imfilter(I,gf);
% gf=makeGaborFilter(0.6,90,8,1,  phi,  bandwidth);
% Y{23}=imfilter(I,gf);
% gf=makeGaborFilter(0.6,135,8,1,  phi,  bandwidth);
% Y{24}=imfilter(I,gf);
hist_=[];
for i=1:numel(Y)
%         histR=imhist(Y{i},16);
%     [histR bin]=histogram(Y{i}(:),[0 1],16);
    edges = linspace(0,1,dim);
    histR=hist(Y{i}(:),edges)';
        histR=histR(:);
    if sum(histR)>0
        histR=histR/(sum(histR)+eps);
    end
    hist_=[hist_;histR];
end
end